from django.shortcuts import render
from django.http import HttpResponse


def index(requests):
    data = {
        "title": "Wow",
        "p": "Текст",
    }

    return render(requests, "App/index.html", data)

def AboutFull(requests):
    data2 = {
        "title": "Информация о работниках",
        "h2": "Ссылки",
        "photo_steve": "https://avatars.mds.yandex.net/get-entity_search/6333097/849794829/SUx182",
        "user": ["Фамилия", "Имя", "Отчество"]
    }

    return render(requests, "App/index.html", data2)

def Homes(requests):
    return render(requests, "App/home.html")

def Contacts(requests):
    data_comp = {
        "title": "Контакты",
        "contacts": ["+7 (391) 296-10-00", "fastfixyt@gmail.com"],
    }
    return render(requests, 'App/contacts.html', data_comp)

def Company(requests):
    return render(requests, 'App/company.html')


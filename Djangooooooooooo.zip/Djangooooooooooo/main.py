import random

class Warrior:
    def __init__(self):
        self.health = 100


unit1 = Warrior()
unit2 = Warrior()

while True:
    l = unit1, unit2
    vibor = random.choice(l)
    if vibor == unit1:
        print(f"Юнит1 дал дамаг юниту2 (осталось хп у юнита2 {unit2.health})")
        unit1.health -= 20
    else:
        print(f"Юнит2 дал дамаг юниту1 (осталось хп у юнита1 {unit1.health})")
        unit2.health -= 20
    if unit1.health == 0:
        print('Юнит 2 победил!')
        break
    elif unit2.health == 0:
        print("Юнит 1 победил")
        break